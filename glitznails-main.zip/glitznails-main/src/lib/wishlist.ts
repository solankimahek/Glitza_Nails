import { useEffect, useState, useCallback } from "react";

const KEY = "glitza-wishlist-v1";

function read(): string[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(KEY) ?? "[]"); } catch { return []; }
}
function write(ids: string[]) { localStorage.setItem(KEY, JSON.stringify(ids)); window.dispatchEvent(new Event("wishlist-change")); }

export function useWishlist() {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    setIds(read());
    const update = () => setIds(read());
    window.addEventListener("wishlist-change", update);
    window.addEventListener("storage", update);
    return () => { window.removeEventListener("wishlist-change", update); window.removeEventListener("storage", update); };
  }, []);
  const toggle = useCallback((id: string) => {
    const current = read();
    const next = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    write(next);
  }, []);
  const has = useCallback((id: string) => ids.includes(id), [ids]);
  return { ids, toggle, has, count: ids.length };
}
