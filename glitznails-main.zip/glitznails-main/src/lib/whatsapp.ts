export const WHATSAPP_NUMBER = "919898752225";
export const BUSINESS_NAME = "Glitza Nails";
export const BUSINESS_LOCATION = "Anand, Gujarat, India";

export function waLink(message: string, phone?: string): string {
  const number = (phone ?? WHATSAPP_NUMBER).replace(/[^\d]/g, "");
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export const waMessages = {
  general: () =>
    `Hi ${BUSINESS_NAME},\nI'd love to know more about your nails and services.`,
  order: (p: { name: string; size?: string; price?: number | string }) =>
    `Hi ${BUSINESS_NAME},\nI would like to order:\n\nProduct: ${p.name}\nSize: ${p.size ?? "—"}\nPrice: ${p.price != null ? `₹${p.price}` : "—"}\n\nPlease assist me. ✨`,
  bookService: (serviceName: string) =>
    `Hi ${BUSINESS_NAME},\nI'd like to book a service:\n\nService: ${serviceName}\n\nPlease share available slots. 💅`,
  custom: (data: Record<string, string | undefined>) => {
    const lines = [
      `Hi ${BUSINESS_NAME}, I'd like a custom nail set:`,
      "",
      `Name: ${data.name ?? "—"}`,
      `Mobile: ${data.mobile ?? "—"}`,
      data.email ? `Email: ${data.email}` : null,
      `Nail Shape: ${data.shape ?? "—"}`,
      `Nail Size: ${data.size ?? "—"}`,
      `Length: ${data.length ?? "—"}`,
      `Color: ${data.color ?? "—"}`,
      `Design Inspiration: ${data.inspiration ?? "—"}`,
      `Occasion: ${data.occasion ?? "—"}`,
      data.notes ? `Notes: ${data.notes}` : null,
      "",
      "Please assist me with the details. ✨",
    ].filter(Boolean);
    return lines.join("\n");
  },
  // Admin -> customer follow-ups
  adminCustomFollowUp: (data: Record<string, string | null | undefined>) => {
    const lines = [
      `Hi ${data.name ?? "there"}, this is ${BUSINESS_NAME} ✨`,
      `Thank you for your custom nail set request! Here's what we noted:`,
      "",
      `Shape: ${data.shape ?? "—"}`,
      `Size: ${data.size ?? "—"}`,
      `Length: ${data.length ?? "—"}`,
      `Color: ${data.color ?? "—"}`,
      `Occasion: ${data.occasion ?? "—"}`,
      data.inspiration ? `Inspiration: ${data.inspiration}` : null,
      "",
      "We'll confirm the design, price and turnaround shortly. 💖",
    ].filter(Boolean);
    return lines.join("\n");
  },
  adminServiceFollowUp: (data: { name?: string | null; service?: string | null }) =>
    `Hi ${data.name ?? "there"}, this is ${BUSINESS_NAME} ✨\nThanks for booking${data.service ? `: ${data.service}` : ""}! Please reply with your preferred date & time and we'll confirm your slot. 💅`,
  adminContactFollowUp: (data: { name?: string | null; message?: string | null }) =>
    `Hi ${data.name ?? "there"}, this is ${BUSINESS_NAME} ✨\nThank you for reaching out${data.message ? ` regarding: "${data.message.slice(0, 80)}${data.message.length > 80 ? "…" : ""}"` : ""}. How can we help you today? 💖`,
};
