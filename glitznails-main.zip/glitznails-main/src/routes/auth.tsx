import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { SiteShell } from "@/components/site/SiteShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Glitza Nails" },
      { name: "description", content: "Sign in to the Glitza Nails admin dashboard." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

const Schema = z.object({
  email: z.string().trim().email("Enter a valid email").max(160),
  password: z.string().min(6, "At least 6 characters").max(72),
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin" });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const r = Schema.safeParse({ email, password });
    if (!r.success) { toast.error(r.error.issues[0]?.message ?? "Check details"); return; }
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword(r.data);
        if (error) throw error;
        toast.success("Welcome back!");
        navigate({ to: "/admin" });
      } else {
        const { error } = await supabase.auth.signUp({
          email: r.data.email,
          password: r.data.password,
          options: { emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) throw error;
        toast.success("Account created. You're signed in.");
        navigate({ to: "/admin" });
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally { setBusy(false); }
  }

  return (
    <SiteShell>
      <section className="mx-auto max-w-md px-5 py-16">
        <div className="card-glass rounded-3xl p-8 space-y-5">
          <div className="text-center space-y-1">
            <h1 className="font-display text-3xl text-mauve-deep">Admin Sign In</h1>
            <p className="text-sm text-muted-foreground">
              {mode === "signin" ? "Access the Glitza dashboard" : "Create an admin account"}
            </p>
          </div>
          <form onSubmit={submit} className="space-y-3">
            <input
              type="email"
              required
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-mauve/20 bg-card px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30"
            />
            <input
              type="password"
              required
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-mauve/20 bg-card px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30"
            />
            <button type="submit" disabled={busy} className="btn-glossy w-full rounded-full py-3 text-sm font-medium disabled:opacity-60">
              {busy ? "Please wait..." : mode === "signin" ? "Sign In" : "Create Account"}
            </button>
          </form>
          <div className="text-center text-sm text-muted-foreground">
            {mode === "signin" ? (
              <>New here? <button className="text-mauve underline" onClick={() => setMode("signup")}>Create account</button></>
            ) : (
              <>Have an account? <button className="text-mauve underline" onClick={() => setMode("signin")}>Sign in</button></>
            )}
          </div>
          <div className="text-center text-xs text-muted-foreground">
            <Link to="/" className="hover:text-mauve">← Back to site</Link>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
