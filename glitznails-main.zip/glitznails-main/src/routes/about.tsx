import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Glitza Nails — Handmade in Anand" },
      { name: "description", content: "Glitza Nails is a handmade press-on nail studio by Mahek Solanki in Anand, Gujarat. Reusable, lightweight and salon quality." },
      { property: "og:title", content: "About Glitza Nails" },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-5">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Our Story</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">A Little Studio. A Lot of Love.</h1>
          <p className="text-muted-foreground leading-relaxed">
            Glitza Nails was born in Anand, Gujarat — out of a love for delicate detail, soft femininity, and the
            quiet luxury of feeling truly put-together. Every set is handmade by Mahek Solanki, sealed for shine,
            and built to be worn again and again.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 lg:px-8 py-16 grid gap-8 sm:grid-cols-3">
        {[
          { t: "Handmade", d: "Each nail is sculpted, painted, and finished by hand in our home studio." },
          { t: "Reusable", d: "Built lightweight and lasting — reapply your favorites again and again." },
          { t: "Custom-Crafted", d: "Send us your inspiration on WhatsApp. We'll bring it to your hands." },
        ].map((f) => (
          <div key={f.t} className="card-glass rounded-3xl p-7 text-center">
            <Heart className="h-6 w-6 mx-auto text-mauve" />
            <div className="font-display text-xl text-mauve-deep mt-3">{f.t}</div>
            <p className="text-sm text-muted-foreground mt-2">{f.d}</p>
          </div>
        ))}
      </section>

      <section className="mx-auto max-w-3xl px-5 lg:px-8 py-12 text-center space-y-4">
        <h2 className="font-display text-3xl text-mauve-deep">We also offer salon services</h2>
        <p className="text-muted-foreground">Soft gel extensions, gel polish, pedicure & more — book in studio.</p>
        <Link to="/services" className="btn-glossy inline-flex rounded-full px-6 py-3 text-sm font-medium">Explore Services</Link>
      </section>
    </SiteShell>
  );
}
