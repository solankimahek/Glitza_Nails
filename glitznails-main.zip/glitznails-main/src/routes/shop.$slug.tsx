import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ChevronLeft, MessageCircle, Minus, Plus, Star, Heart } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";
import { productBySlugQuery, productsQuery } from "@/lib/products.queries";
import { waLink, waMessages } from "@/lib/whatsapp";
import { useWishlist } from "@/lib/wishlist";

export const Route = createFileRoute("/shop/$slug")({
  loader: async ({ context, params }) => {
    const product = await context.queryClient.ensureQueryData(productBySlugQuery(params.slug));
    if (!product) throw notFound();
    context.queryClient.ensureQueryData(productsQuery());
  },
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug.replace(/-/g, " ")} — Glitza Nails` },
      { property: "og:url", content: `/shop/${params.slug}` },
    ],
    links: [{ rel: "canonical", href: `/shop/${params.slug}` }],
  }),
  errorComponent: ({ error }) => <SiteShell><div className="p-10 text-center">Error: {error.message}</div></SiteShell>,
  notFoundComponent: () => (
    <SiteShell>
      <div className="p-16 text-center space-y-4">
        <h1 className="font-display text-3xl text-mauve-deep">Product not found</h1>
        <Link to="/shop" className="text-mauve underline">Back to shop</Link>
      </div>
    </SiteShell>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { data: product } = useSuspenseQuery(productBySlugQuery(slug));
  const { data: all } = useSuspenseQuery(productsQuery());
  const [size, setSize] = useState(product!.sizes[1] ?? product!.sizes[0]);
  const [qty, setQty] = useState(1);
  const [imageIdx, setImageIdx] = useState(0);
  const [zoom, setZoom] = useState(false);
  const { has, toggle } = useWishlist();

  if (!product) return null;
  const suggestions = all.filter((p) => p.id !== product.id).slice(0, 4);
  const totalPrice = product.price * qty;

  return (
    <SiteShell>
      <div className="mx-auto max-w-7xl px-5 lg:px-8 pt-6">
        <Link to="/shop" className="inline-flex items-center gap-1 text-sm text-mauve hover:text-mauve-deep">
          <ChevronLeft className="h-4 w-4" /> Back to shop
        </Link>
      </div>

      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-8 grid gap-10 lg:grid-cols-2">
        <div className="space-y-4">
          <div
            className="relative aspect-square rounded-3xl overflow-hidden bg-blush border border-mauve/10 cursor-zoom-in"
            onMouseEnter={() => setZoom(true)}
            onMouseLeave={() => setZoom(false)}
          >
            <img
              src={product.images[imageIdx] ?? product.images[0]}
              alt={product.name}
              width={1024}
              height={1024}
              className={`w-full h-full object-cover transition-transform duration-500 ${zoom ? "scale-150" : "scale-100"}`}
            />
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((src, i) => (
                <button
                  key={i}
                  onClick={() => setImageIdx(i)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 ${i === imageIdx ? "border-mauve" : "border-transparent"}`}
                >
                  <img src={src} alt="" className="w-full h-full object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-mauve">{product.category ?? "Press-On Nails"}</div>
            <h1 className="font-display text-3xl sm:text-4xl text-mauve-deep mt-2">{product.name}</h1>
            <div className="flex items-center gap-2 mt-2">
              {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-gold text-gold" />)}
              <span className="text-xs text-muted-foreground">(4.9)</span>
            </div>
          </div>
          <div className="text-3xl font-display text-mauve">₹{product.price}</div>
          <p className="text-foreground/80 leading-relaxed">{product.description}</p>

          <div>
            <div className="text-sm font-medium text-mauve-deep mb-2">Size</div>
            <div className="flex gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`w-12 h-12 rounded-full border-2 font-medium transition ${size === s ? "border-mauve bg-mauve text-cream" : "border-mauve/20 text-mauve-deep hover:border-mauve/50"}`}
                >
                  {s}
                </button>
              ))}
            </div>
            <Link to="/size-guide" className="text-xs text-mauve underline mt-2 inline-block">Size guide</Link>
          </div>

          <div>
            <div className="text-sm font-medium text-mauve-deep mb-2">Quantity</div>
            <div className="inline-flex items-center border border-mauve/20 rounded-full">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-10 h-10 inline-flex items-center justify-center text-mauve-deep"><Minus className="h-4 w-4" /></button>
              <span className="w-10 text-center font-medium">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="w-10 h-10 inline-flex items-center justify-center text-mauve-deep"><Plus className="h-4 w-4" /></button>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <a
              href={waLink(waMessages.order({ name: `${product.name} × ${qty}`, size, price: totalPrice }))}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 btn-glossy rounded-full py-3.5 text-sm font-medium inline-flex items-center justify-center gap-2"
            >
              <MessageCircle className="h-4 w-4" /> Order on WhatsApp — ₹{totalPrice}
            </a>
            <button
              onClick={() => toggle(product.id)}
              aria-label="Wishlist"
              className="w-12 h-12 inline-flex items-center justify-center rounded-full border border-mauve/30 text-mauve hover:bg-blush"
            >
              <Heart className={`h-5 w-5 ${has(product.id) ? "fill-mauve" : ""}`} />
            </button>
          </div>
        </div>
      </section>

      {suggestions.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 lg:px-8 py-12">
          <h2 className="font-display text-2xl text-mauve-deep mb-6">You might also love</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {suggestions.map((p) => (
              <Link key={p.id} to="/shop/$slug" params={{ slug: p.slug }} className="hover-lift rounded-3xl overflow-hidden bg-card border border-mauve/10 group">
                <div className="aspect-square bg-blush overflow-hidden">
                  <img src={p.images[0]} alt={p.name} loading="lazy" width={400} height={400} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="p-4">
                  <div className="font-display text-mauve-deep">{p.name}</div>
                  <div className="text-mauve text-sm mt-1">₹{p.price}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </SiteShell>
  );
}
