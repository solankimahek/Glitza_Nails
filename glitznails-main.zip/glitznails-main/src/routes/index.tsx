import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Heart, Star, MessageCircle } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";
import { productsQuery, testimonialsQuery } from "@/lib/products.queries";
import { waLink, waMessages } from "@/lib/whatsapp";
import heroImg from "@/assets/hero-nails.jpg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Glitza Nails — Luxury Handmade Press-On Nails | Anand, Gujarat" },
      { name: "description", content: "Luxury, reusable, handmade press-on nails crafted with love. Custom designs and salon services by Mahek Solanki in Anand, Gujarat." },
      { property: "og:title", content: "Glitza Nails — Luxury Handmade Press-On Nails" },
      { property: "og:description", content: "Reusable · Handmade · Salon Quality · Custom Designs." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(productsQuery());
    context.queryClient.ensureQueryData(testimonialsQuery());
  },
  component: HomePage,
});

function HomePage() {
  const { data: products } = useSuspenseQuery(productsQuery());
  const { data: testimonials } = useSuspenseQuery(testimonialsQuery());
  const featured = products.filter((p) => p.is_featured).slice(0, 4);

  return (
    <SiteShell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-blush via-background to-cream" />
          <div className="absolute -top-32 -right-32 w-[36rem] h-[36rem] rounded-full opacity-40 blur-3xl" style={{ background: "radial-gradient(circle, oklch(0.78 0.12 75 / 0.5), transparent 70%)" }} />
          <div className="absolute -bottom-32 -left-32 w-[36rem] h-[36rem] rounded-full opacity-50 blur-3xl" style={{ background: "radial-gradient(circle, oklch(0.58 0.075 10 / 0.35), transparent 70%)" }} />
        </div>
        <div className="mx-auto max-w-7xl px-5 lg:px-8 py-16 md:py-24 lg:py-32 grid gap-12 lg:grid-cols-2 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
            className="space-y-7"
          >
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-card/70 backdrop-blur-md border border-mauve/15 text-xs tracking-[0.18em] uppercase text-mauve-deep">
              <Sparkles className="h-3.5 w-3.5 text-gold" /> Handmade in Anand
            </span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-mauve-deep">
              Luxury Press-On Nails
              <br />
              <span className="italic text-gradient-mauve">Crafted Just For You</span>
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground max-w-xl leading-relaxed">
              Reusable · Handmade · Salon Quality · Custom Designs. Each set is sculpted with detail,
              shipped from our Anand studio, and ready to make every moment feel a little more golden.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/shop" className="btn-glossy inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium">
                Shop Press-On Nails <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/custom" className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium border border-mauve/30 text-mauve-deep hover:bg-blush transition">
                Customize Your Nails
              </Link>
              <a href={waLink(waMessages.general())} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium border border-mauve/30 text-mauve-deep hover:bg-blush transition">
                <MessageCircle className="h-4 w-4" /> Book Service
              </a>
            </div>
            <div className="flex items-center gap-6 pt-4 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5"><Star className="h-4 w-4 fill-gold text-gold" /> 4.9 from 200+ orders</div>
              <div className="hidden sm:flex items-center gap-1.5"><Heart className="h-4 w-4 text-mauve" /> Reusable up to 30 wears</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, ease: [0.2, 0.8, 0.2, 1] }}
            className="relative"
          >
            <div className="relative aspect-[4/5] rounded-[2.5rem] overflow-hidden shadow-glow ring-1 ring-mauve/10">
              <img src={heroImg.url} alt="Luxury press-on nails in nude pink" className="w-full h-full object-cover" width={1600} height={1200} />
            </div>
            <div className="absolute -bottom-6 -left-6 card-glass rounded-2xl px-5 py-4 shadow-soft animate-float">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold to-mauve flex items-center justify-center text-cream">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-mauve-deep/70">New drop</div>
                  <div className="font-display text-mauve-deep">Bridal Collection ’26</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* INTRO STRIP */}
      <section className="py-12 bg-blush/50 border-y border-mauve/10">
        <div className="mx-auto max-w-6xl px-5 grid gap-6 sm:grid-cols-3 text-center">
          {[
            { t: "Handcrafted", d: "Sculpted by hand, sealed for shine, finished with care." },
            { t: "Reusable", d: "Each set lasts up to 30 wears with gentle care." },
            { t: "Custom-Made", d: "Tell us your vision on WhatsApp — we'll bring it to life." },
          ].map((f) => (
            <div key={f.t} className="space-y-2">
              <div className="font-display text-xl text-mauve-deep">{f.t}</div>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-20">
        <div className="flex items-end justify-between gap-4 mb-10">
          <div>
            <span className="text-xs uppercase tracking-[0.2em] text-mauve">Bestsellers</span>
            <h2 className="font-display text-3xl sm:text-4xl text-mauve-deep mt-2">Loved by Glitza Girls</h2>
          </div>
          <Link to="/shop" className="text-sm text-mauve hover:text-mauve-deep flex items-center gap-1">View all <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((p) => (
            <Link
              key={p.id}
              to="/shop/$slug"
              params={{ slug: p.slug }}
              className="group hover-lift rounded-3xl overflow-hidden bg-card border border-mauve/10"
            >
              <div className="aspect-square overflow-hidden bg-blush">
                <img
                  src={p.images[0]}
                  alt={p.name}
                  loading="lazy"
                  width={600}
                  height={600}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="p-5">
                <div className="font-display text-lg text-mauve-deep">{p.name}</div>
                <div className="mt-1 flex items-center justify-between">
                  <span className="text-mauve font-medium">₹{p.price}</span>
                  <span className="text-xs text-muted-foreground">{p.sizes.join(" · ")}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* CUSTOM CTA */}
      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-16">
        <div className="relative overflow-hidden rounded-[2.5rem] p-10 lg:p-16 text-center" style={{ background: "linear-gradient(135deg, oklch(0.58 0.075 10), oklch(0.42 0.07 12))" }}>
          <div className="absolute inset-0 opacity-30" style={{ background: "radial-gradient(circle at 20% 20%, oklch(0.85 0.10 80 / 0.6), transparent 50%)" }} />
          <div className="relative max-w-2xl mx-auto space-y-5 text-cream">
            <Sparkles className="h-6 w-6 mx-auto text-gold" />
            <h2 className="font-display text-3xl sm:text-4xl">Dreaming of something just for you?</h2>
            <p className="opacity-90">Share your inspiration, color, and length — we'll craft a one-of-a-kind set just for your moment.</p>
            <Link to="/custom" className="inline-flex items-center gap-2 rounded-full px-7 py-3 bg-cream text-mauve-deep font-medium hover:bg-white transition">
              Start Your Custom Set <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-20">
        <div className="text-center mb-12">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Glitza Girls</span>
          <h2 className="font-display text-3xl sm:text-4xl text-mauve-deep mt-2">Love Notes</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {testimonials.slice(0, 4).map((t) => (
            <div key={t.id} className="card-glass rounded-3xl p-6 hover-lift">
              <div className="flex gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-sm text-foreground/85 italic leading-relaxed">“{t.review}”</p>
              <div className="mt-4 text-sm font-medium text-mauve-deep">— {t.name}</div>
            </div>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
