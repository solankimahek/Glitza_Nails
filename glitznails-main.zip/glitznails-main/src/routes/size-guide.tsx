import { createFileRoute } from "@tanstack/react-router";
import { Ruler } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";

export const Route = createFileRoute("/size-guide")({
  head: () => ({
    meta: [
      { title: "Size Guide — Glitza Nails" },
      { name: "description", content: "How to measure your nails for the perfect Glitza press-on fit. S, M, L sizes explained." },
      { property: "og:url", content: "/size-guide" },
    ],
    links: [{ rel: "canonical", href: "/size-guide" }],
  }),
  component: SizeGuide,
});

const ROWS = [
  { size: "Small (S)", thumb: "13–15 mm", index: "11–12 mm", middle: "12–13 mm", ring: "10–11 mm", pinky: "9–10 mm" },
  { size: "Medium (M)", thumb: "16–17 mm", index: "12–13 mm", middle: "13–14 mm", ring: "11–12 mm", pinky: "10–11 mm" },
  { size: "Large (L)", thumb: "18–20 mm", index: "13–14 mm", middle: "14–15 mm", ring: "12–13 mm", pinky: "11–12 mm" },
];

function SizeGuide() {
  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-4">
          <Ruler className="h-6 w-6 mx-auto text-mauve" />
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Size Guide</h1>
          <p className="text-muted-foreground">Find your perfect Glitza fit in under a minute.</p>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 lg:px-8 py-12 space-y-8">
        <div className="card-glass rounded-3xl p-7">
          <h2 className="font-display text-2xl text-mauve-deep mb-4">How to measure</h2>
          <ol className="space-y-3 text-sm text-foreground/85 list-decimal list-inside leading-relaxed">
            <li>Take a soft measuring tape (or a strip of paper).</li>
            <li>Wrap it across the widest part of each nail bed.</li>
            <li>Note the measurement in millimeters.</li>
            <li>Match each finger to the chart below — sizes can mix across fingers.</li>
            <li>Still unsure? Send a clear photo of your hand on WhatsApp and we'll guide you.</li>
          </ol>
        </div>

        <div className="rounded-3xl overflow-hidden border border-mauve/10 bg-card">
          <table className="w-full text-sm">
            <thead className="bg-blush/60 text-mauve-deep">
              <tr><th className="text-left p-3">Size</th><th className="p-3">Thumb</th><th className="p-3">Index</th><th className="p-3">Middle</th><th className="p-3">Ring</th><th className="p-3">Pinky</th></tr>
            </thead>
            <tbody>
              {ROWS.map((r) => (
                <tr key={r.size} className="border-t border-mauve/10 text-center">
                  <td className="p-3 text-left font-display text-mauve-deep">{r.size}</td>
                  <td className="p-3">{r.thumb}</td><td className="p-3">{r.index}</td><td className="p-3">{r.middle}</td><td className="p-3">{r.ring}</td><td className="p-3">{r.pinky}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </SiteShell>
  );
}
