import { createFileRoute } from "@tanstack/react-router";
import { Instagram, MapPin, MessageCircle, Phone } from "lucide-react";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { SiteShell } from "@/components/site/SiteShell";
import { supabase } from "@/integrations/supabase/client";
import { waLink, waMessages } from "@/lib/whatsapp";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Glitza Nails, Anand" },
      { name: "description", content: "Get in touch with Glitza Nails in Anand, Gujarat. WhatsApp +91 98987 52225." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

const Schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(120).optional().or(z.literal("")),
  mobile: z.string().trim().max(20).optional().or(z.literal("")),
  message: z.string().trim().min(5).max(1000),
});

function ContactPage() {
  const [data, setData] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const set = (k: string, v: string) => setData((d) => ({ ...d, [k]: v }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const r = Schema.safeParse(data);
    if (!r.success) { toast.error(r.error.issues[0]?.message ?? "Please check details"); return; }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("contact_requests").insert({
        name: r.data.name, email: r.data.email || null, mobile: r.data.mobile || null, message: r.data.message,
      });
      if (error) throw error;
      toast.success("Thank you! We'll be in touch soon.");
      setData({});
    } catch (err) {
      toast.error((err as Error).message);
    } finally { setSubmitting(false); }
  }

  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-4">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Visit · Chat · Follow</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Get in Touch</h1>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 lg:px-8 py-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="card-glass rounded-3xl p-7 space-y-4">
            <h2 className="font-display text-xl text-mauve-deep">Glitza Nails by Mahek Solanki</h2>
            <div className="flex items-center gap-3 text-sm"><MapPin className="h-4 w-4 text-mauve" /> Anand, Gujarat, India</div>
            <div className="flex items-center gap-3 text-sm"><Phone className="h-4 w-4 text-mauve" /> +91 98987 52225</div>
            <div className="flex items-center gap-3 text-sm"><Instagram className="h-4 w-4 text-mauve" /> @glitzanails</div>
            <div className="flex gap-2 pt-2">
              <a href={waLink(waMessages.general())} target="_blank" rel="noopener noreferrer" className="btn-glossy inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium">
                <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium border border-mauve/30 text-mauve-deep hover:bg-blush">
                <Instagram className="h-4 w-4" /> Instagram
              </a>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden border border-mauve/10 h-64">
            <iframe
              title="Glitza Nails location"
              src="https://www.google.com/maps?q=Anand,Gujarat&output=embed"
              className="w-full h-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

        <form onSubmit={onSubmit} className="card-glass rounded-3xl p-7 space-y-4">
          <h2 className="font-display text-xl text-mauve-deep">Send a message</h2>
          <input required placeholder="Your name" value={data.name ?? ""} onChange={(e) => set("name", e.target.value)} className={inputCls} />
          <input type="email" placeholder="Email (optional)" value={data.email ?? ""} onChange={(e) => set("email", e.target.value)} className={inputCls} />
          <input placeholder="Mobile (optional)" value={data.mobile ?? ""} onChange={(e) => set("mobile", e.target.value)} className={inputCls} />
          <textarea required rows={5} placeholder="Tell us how we can help..." value={data.message ?? ""} onChange={(e) => set("message", e.target.value)} className={inputCls} />
          <button type="submit" disabled={submitting} className="btn-glossy w-full rounded-full py-3 text-sm font-medium disabled:opacity-60">
            {submitting ? "Sending..." : "Send Message"}
          </button>
        </form>
      </section>
    </SiteShell>
  );
}
const inputCls = "w-full rounded-xl border border-mauve/20 bg-card px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30";
