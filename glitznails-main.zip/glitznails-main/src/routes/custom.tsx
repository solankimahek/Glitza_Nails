import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MessageCircle, Sparkles } from "lucide-react";
import { z } from "zod";
import { SiteShell } from "@/components/site/SiteShell";
import { waLink, waMessages } from "@/lib/whatsapp";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/custom")({
  head: () => ({
    meta: [
      { title: "Custom Nail Set — Glitza Nails" },
      { name: "description", content: "Design your dream press-on set. Tell us your shape, length, color and inspiration — we'll craft it just for you." },
      { property: "og:url", content: "/custom" },
    ],
    links: [{ rel: "canonical", href: "/custom" }],
  }),
  component: CustomPage,
});

const Schema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(80),
  mobile: z.string().trim().min(7, "Enter a valid mobile").max(20),
  email: z.string().trim().email("Invalid email").max(120).optional().or(z.literal("")),
  shape: z.string().max(40).optional().or(z.literal("")),
  size: z.string().max(40).optional().or(z.literal("")),
  length: z.string().max(40).optional().or(z.literal("")),
  color: z.string().max(80).optional().or(z.literal("")),
  inspiration: z.string().max(400).optional().or(z.literal("")),
  occasion: z.string().max(80).optional().or(z.literal("")),
  notes: z.string().max(500).optional().or(z.literal("")),
});

const SHAPES = ["Almond", "Coffin", "Stiletto", "Square", "Round", "Oval"];
const SIZES = ["Small (S)", "Medium (M)", "Large (L)", "Not sure"];
const LENGTHS = ["Short", "Medium", "Long", "Extra Long"];

function CustomPage() {
  const [data, setData] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const set = (k: string, v: string) => setData((d) => ({ ...d, [k]: v }));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const result = Schema.safeParse(data);
    if (!result.success) {
      toast.error(result.error.issues[0]?.message ?? "Please check your details");
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("custom_orders").insert({
        name: result.data.name,
        mobile: result.data.mobile,
        email: result.data.email || null,
        shape: result.data.shape || null,
        size: result.data.size || null,
        length: result.data.length || null,
        color: result.data.color || null,
        inspiration: result.data.inspiration || null,
        occasion: result.data.occasion || null,
        notes: result.data.notes || null,
        images: [],
      });
      if (error) console.warn(error);
      const url = waLink(waMessages.custom(data));
      window.open(url, "_blank");
      toast.success("Opening WhatsApp with your request...");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-5">
          <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-mauve">
            <Sparkles className="h-3.5 w-3.5 text-gold" /> Made for You
          </span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Custom Nail Set</h1>
          <p className="text-muted-foreground">Share your vision and we'll handcraft a one-of-a-kind set, just for your moment.</p>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 lg:px-8 py-12">
        <form onSubmit={onSubmit} className="space-y-5 card-glass rounded-3xl p-7 sm:p-10">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Your Name *"><input required value={data.name ?? ""} onChange={(e) => set("name", e.target.value)} className={inputCls} /></Field>
            <Field label="Mobile Number *"><input required type="tel" value={data.mobile ?? ""} onChange={(e) => set("mobile", e.target.value)} className={inputCls} /></Field>
            <Field label="Email (optional)"><input type="email" value={data.email ?? ""} onChange={(e) => set("email", e.target.value)} className={inputCls} /></Field>
            <Field label="Occasion"><input value={data.occasion ?? ""} onChange={(e) => set("occasion", e.target.value)} placeholder="Wedding, party..." className={inputCls} /></Field>
            <Field label="Nail Shape">
              <select value={data.shape ?? ""} onChange={(e) => set("shape", e.target.value)} className={inputCls}>
                <option value="">Select shape</option>
                {SHAPES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Nail Size">
              <select value={data.size ?? ""} onChange={(e) => set("size", e.target.value)} className={inputCls}>
                <option value="">Select size</option>
                {SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Length">
              <select value={data.length ?? ""} onChange={(e) => set("length", e.target.value)} className={inputCls}>
                <option value="">Select length</option>
                {LENGTHS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Color Preference"><input value={data.color ?? ""} onChange={(e) => set("color", e.target.value)} placeholder="Soft mauve, nude..." className={inputCls} /></Field>
          </div>
          <Field label="Design Inspiration"><textarea rows={3} value={data.inspiration ?? ""} onChange={(e) => set("inspiration", e.target.value)} placeholder="Describe the design or share a Pinterest link..." className={inputCls} /></Field>
          <Field label="Additional Notes"><textarea rows={2} value={data.notes ?? ""} onChange={(e) => set("notes", e.target.value)} className={inputCls} /></Field>
          <p className="text-xs text-muted-foreground">Have inspiration photos? Share them in the WhatsApp chat that opens next.</p>
          <button
            type="submit"
            disabled={submitting}
            className="btn-glossy w-full rounded-full py-3.5 text-sm font-medium inline-flex items-center justify-center gap-2 disabled:opacity-60"
          >
            <MessageCircle className="h-4 w-4" /> {submitting ? "Sending..." : "Send via WhatsApp"}
          </button>
        </form>
      </section>
    </SiteShell>
  );
}

const inputCls = "w-full rounded-xl border border-mauve/20 bg-card px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block space-y-1.5"><span className="text-xs font-medium text-mauve-deep">{label}</span>{children}</label>;
}
