import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { MessageCircle } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";
import { servicesQuery } from "@/lib/products.queries";
import { waLink, waMessages } from "@/lib/whatsapp";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Nail Services — Glitza Nails, Anand" },
      { name: "description", content: "Soft gel nail extensions, gel polish (hands & toes), and bridal styling in Anand. Book on WhatsApp." },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  loader: ({ context }) => { context.queryClient.ensureQueryData(servicesQuery()); },
  errorComponent: ({ error }) => <SiteShell><div className="p-10">Error: {error.message}</div></SiteShell>,
  notFoundComponent: () => <SiteShell><div className="p-10">Not found</div></SiteShell>,
  component: ServicesPage,
});

function ServicesPage() {
  const { data: services } = useSuspenseQuery(servicesQuery());
  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-5">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">In-Studio</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Salon Services</h1>
          <p className="text-muted-foreground">Professional nail care at Glitza Studio, Anand. Book your slot on WhatsApp.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-16">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <div key={s.id} className="rounded-3xl overflow-hidden bg-card border border-mauve/10 hover-lift">
              {s.image && (
                <div className="aspect-[4/3] overflow-hidden bg-blush">
                  <img src={s.image} alt={s.name} loading="lazy" width={600} height={450} className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
                </div>
              )}
              <div className="p-6 space-y-3">
                <div className="text-xs uppercase tracking-wider text-mauve">{s.category}</div>
                <div className="font-display text-xl text-mauve-deep">{s.name}</div>
                <p className="text-sm text-muted-foreground">{s.description}</p>
                <div className="flex items-center justify-between pt-2">
                  {s.price_from != null && <div className="text-mauve font-medium">from ₹{s.price_from}</div>}
                  <a
                    href={waLink(waMessages.bookService(s.name))}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      // Fire-and-forget: log booking intent for the admin inbox.
                      void supabase.from("contact_requests").insert({
                        name: "Website visitor",
                        message: `Wants to book: ${s.name}`,
                        kind: "service_booking",
                        service_name: s.name,
                      });
                    }}
                    className="btn-glossy inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium"
                  >
                    <MessageCircle className="h-3.5 w-3.5" /> Book
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
