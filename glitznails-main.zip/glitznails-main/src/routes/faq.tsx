import { createFileRoute } from "@tanstack/react-router";
import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { SiteShell } from "@/components/site/SiteShell";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Glitza Nails" },
      { name: "description", content: "Everything about Glitza press-on nails: how long they last, application, removal, customization." },
      { property: "og:url", content: "/faq" },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: FAQS.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      }),
    }],
  }),
  component: FAQPage,
});

const FAQS = [
  { q: "How long do press-on nails last?", a: "With proper application, Glitza press-ons last 7–14 days. With gentle care, each set can be reused up to 30 wears." },
  { q: "Can they be reused?", a: "Yes! Remove gently, clean off any residue, and store in the original box. Reapply with fresh adhesive tabs or nail glue." },
  { q: "How do I apply them?", a: "Push back cuticles, buff your natural nail, swipe with alcohol, apply glue or tabs, press firmly for 30 seconds. A full guide ships with every order." },
  { q: "How do I remove them?", a: "Soak in warm soapy water for 10–15 minutes, then gently lift from the side. Never pull dry." },
  { q: "What's the delivery time?", a: "Ready-to-ship sets dispatch in 1–2 days. Custom sets are crafted in 5–7 days. Delivery across India in 3–6 days." },
  { q: "Do you take custom orders?", a: "Absolutely. Share your inspiration on our Custom page and we'll craft a one-of-a-kind set just for you." },
  { q: "Are they damaging to my natural nails?", a: "No — our tabs and gentle glue won't damage healthy nails when applied and removed correctly." },
];

function FAQPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-4">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Help</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Frequently Asked</h1>
          <p className="text-muted-foreground">Everything you might wonder before your first Glitza set.</p>
        </div>
      </section>
      <section className="mx-auto max-w-3xl px-5 lg:px-8 py-12 space-y-3">
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={f.q} className="rounded-2xl border border-mauve/15 bg-card overflow-hidden">
              <button
                type="button"
                onClick={() => setOpen(isOpen ? null : i)}
                className="w-full px-6 py-4 flex items-center justify-between text-left"
              >
                <span className="font-display text-mauve-deep">{f.q}</span>
                <ChevronDown className={`h-4 w-4 text-mauve transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {isOpen && <div className="px-6 pb-5 text-sm text-foreground/80 leading-relaxed">{f.a}</div>}
            </div>
          );
        })}
      </section>
    </SiteShell>
  );
}
