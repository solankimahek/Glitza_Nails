import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { SiteShell } from "@/components/site/SiteShell";
import { galleryQuery } from "@/lib/products.queries";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Glitza Nails" },
      { name: "description", content: "Looks, sets, and behind-the-scenes from the Glitza Nails studio in Anand." },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  loader: ({ context }) => { context.queryClient.ensureQueryData(galleryQuery()); },
  errorComponent: ({ error }) => <SiteShell><div className="p-10">Error: {error.message}</div></SiteShell>,
  notFoundComponent: () => <SiteShell><div className="p-10">Not found</div></SiteShell>,
  component: GalleryPage,
});

function GalleryPage() {
  const { data: items } = useSuspenseQuery(galleryQuery());
  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background">
        <div className="mx-auto max-w-4xl px-5 lg:px-8 py-20 text-center space-y-5">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Looks</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep">Gallery</h1>
          <p className="text-muted-foreground">A little inspiration for your next set.</p>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-12">
        <div className="columns-2 md:columns-3 lg:columns-4 gap-4 [column-fill:_balance]">
          {items.map((g, i) => (
            <div key={g.id} className="mb-4 break-inside-avoid rounded-2xl overflow-hidden bg-blush hover-lift group">
              <img
                src={g.image}
                alt={g.caption ?? "Glitza Nails"}
                loading={i < 4 ? "eager" : "lazy"}
                className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
              />
              {g.caption && <div className="p-3 text-xs text-mauve-deep">{g.caption}</div>}
            </div>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
