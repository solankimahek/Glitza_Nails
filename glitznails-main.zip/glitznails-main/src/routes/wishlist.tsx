import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Heart, MessageCircle } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";
import { productsQuery } from "@/lib/products.queries";
import { useWishlist } from "@/lib/wishlist";
import { waLink, waMessages } from "@/lib/whatsapp";

export const Route = createFileRoute("/wishlist")({
  head: () => ({
    meta: [{ title: "Wishlist — Glitza Nails" }, { name: "robots", content: "noindex" }],
  }),
  loader: ({ context }) => { context.queryClient.ensureQueryData(productsQuery()); },
  errorComponent: ({ error }) => <SiteShell><div className="p-10">Error: {error.message}</div></SiteShell>,
  notFoundComponent: () => <SiteShell><div className="p-10">Not found</div></SiteShell>,
  component: WishlistPage,
});

function WishlistPage() {
  const { data: all } = useSuspenseQuery(productsQuery());
  const { ids, toggle } = useWishlist();
  const items = all.filter((p) => ids.includes(p.id));
  return (
    <SiteShell>
      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-16">
        <div className="text-center mb-10 space-y-3">
          <Heart className="h-6 w-6 mx-auto text-mauve fill-mauve" />
          <h1 className="font-display text-4xl text-mauve-deep">Your Wishlist</h1>
        </div>
        {items.length === 0 ? (
          <div className="text-center text-muted-foreground py-12 space-y-4">
            <p>Your wishlist is empty.</p>
            <Link to="/shop" className="btn-glossy inline-flex rounded-full px-6 py-3 text-sm">Browse Shop</Link>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {items.map((p) => (
              <div key={p.id} className="rounded-3xl overflow-hidden bg-card border border-mauve/10 hover-lift group">
                <Link to="/shop/$slug" params={{ slug: p.slug }} className="block aspect-square overflow-hidden bg-blush">
                  <img src={p.images[0]} alt={p.name} loading="lazy" width={400} height={400} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </Link>
                <div className="p-4 space-y-3">
                  <div className="font-display text-mauve-deep">{p.name}</div>
                  <div className="text-mauve text-sm">₹{p.price}</div>
                  <div className="flex gap-2">
                    <a href={waLink(waMessages.order({ name: p.name, price: p.price }))} target="_blank" rel="noopener noreferrer" className="btn-glossy flex-1 rounded-full py-2 text-xs font-medium inline-flex items-center justify-center gap-1.5">
                      <MessageCircle className="h-3 w-3" /> Order
                    </a>
                    <button onClick={() => toggle(p.id)} aria-label="Remove" className="w-9 h-9 inline-flex items-center justify-center rounded-full border border-mauve/30 text-mauve">
                      <Heart className="h-4 w-4 fill-mauve" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </SiteShell>
  );
}
