import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Heart, MessageCircle, Search } from "lucide-react";
import { SiteShell } from "@/components/site/SiteShell";
import { productsQuery } from "@/lib/products.queries";
import { useWishlist } from "@/lib/wishlist";
import { waLink, waMessages } from "@/lib/whatsapp";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop Press-On Nails — Glitza Nails" },
      { name: "description", content: "Browse handmade, reusable press-on nail sets in nude, rose gold, french, burgundy, floral and chrome. Order on WhatsApp." },
      { property: "og:title", content: "Shop Press-On Nails — Glitza Nails" },
      { property: "og:url", content: "/shop" },
    ],
    links: [{ rel: "canonical", href: "/shop" }],
  }),
  loader: ({ context }) => { context.queryClient.ensureQueryData(productsQuery()); },
  errorComponent: ({ error }) => <SiteShell><div className="p-10 text-center">Couldn't load shop: {error.message}</div></SiteShell>,
  notFoundComponent: () => <SiteShell><div className="p-10 text-center">Not found.</div></SiteShell>,
  component: ShopPage,
});

type Sort = "newest" | "price-asc" | "price-desc" | "name";

function ShopPage() {
  const { data: products } = useSuspenseQuery(productsQuery());
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<Sort>("newest");
  const { has, toggle } = useWishlist();

  const view = useMemo(() => {
    let r = [...products];
    if (q.trim()) {
      const s = q.toLowerCase();
      r = r.filter((p) => p.name.toLowerCase().includes(s) || (p.description ?? "").toLowerCase().includes(s));
    }
    switch (sort) {
      case "price-asc": r.sort((a, b) => a.price - b.price); break;
      case "price-desc": r.sort((a, b) => b.price - a.price); break;
      case "name": r.sort((a, b) => a.name.localeCompare(b.name)); break;
      default: r.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }
    return r;
  }, [products, q, sort]);

  return (
    <SiteShell>
      <section className="bg-gradient-to-b from-blush/60 to-background border-b border-mauve/10">
        <div className="mx-auto max-w-7xl px-5 lg:px-8 py-14 text-center">
          <span className="text-xs uppercase tracking-[0.2em] text-mauve">Collection</span>
          <h1 className="font-display text-4xl sm:text-5xl text-mauve-deep mt-2">Press-On Nails</h1>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto">Handcrafted sets, ready to wear. Each design is reusable, lightweight, and salon-quality.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 lg:px-8 py-8">
        <div className="grid gap-3 sm:flex sm:items-center sm:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="h-4 w-4 absolute left-4 top-1/2 -translate-y-1/2 text-mauve" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search nail sets..."
              className="w-full rounded-full border border-mauve/20 bg-card pl-11 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-mauve/30"
            />
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as Sort)}
            className="rounded-full border border-mauve/20 bg-card px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30"
          >
            <option value="newest">Newest</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="name">Name: A–Z</option>
          </select>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 lg:px-8 pb-20">
        {view.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">No nail sets match your search.</div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {view.map((p) => (
              <div key={p.id} className="group rounded-3xl overflow-hidden bg-card border border-mauve/10 hover-lift flex flex-col">
                <Link to="/shop/$slug" params={{ slug: p.slug }} className="block relative">
                  <div className="aspect-square overflow-hidden bg-blush">
                    <img src={p.images[0]} alt={p.name} loading="lazy" width={600} height={600} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  </div>
                  <button
                    type="button"
                    onClick={(e) => { e.preventDefault(); toggle(p.id); }}
                    aria-label="Wishlist"
                    className="absolute top-3 right-3 w-9 h-9 inline-flex items-center justify-center rounded-full bg-card/90 backdrop-blur-md text-mauve hover:bg-card"
                  >
                    <Heart className={`h-4 w-4 ${has(p.id) ? "fill-mauve" : ""}`} />
                  </button>
                </Link>
                <div className="p-5 flex-1 flex flex-col">
                  <div className="font-display text-lg text-mauve-deep">{p.name}</div>
                  <div className="mt-1 text-sm text-muted-foreground line-clamp-2">{p.description}</div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-mauve font-medium text-lg">₹{p.price}</span>
                    <span className="text-xs text-muted-foreground">{p.sizes.join(" · ")}</span>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Link to="/shop/$slug" params={{ slug: p.slug }} className="flex-1 text-center rounded-full border border-mauve/30 text-mauve-deep py-2 text-sm hover:bg-blush transition">
                      View
                    </Link>
                    <a
                      href={waLink(waMessages.order({ name: p.name, price: p.price }))}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 btn-glossy rounded-full py-2 text-sm font-medium text-center inline-flex items-center justify-center gap-1.5"
                    >
                      <MessageCircle className="h-3.5 w-3.5" /> Order
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </SiteShell>
  );
}
