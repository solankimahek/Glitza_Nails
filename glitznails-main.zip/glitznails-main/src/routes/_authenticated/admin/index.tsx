import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Package, Scissors, Sparkles, Inbox, MessageCircle } from "lucide-react";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminHome,
});

function AdminHome() {
  const [stats, setStats] = useState({ products: 0, services: 0, customOrdersNew: 0, inboxNew: 0 });

  useEffect(() => {
    (async () => {
      const [p, s, co, cr] = await Promise.all([
        supabase.from("products").select("*", { count: "exact", head: true }),
        supabase.from("services").select("*", { count: "exact", head: true }),
        supabase.from("custom_orders").select("*", { count: "exact", head: true }).eq("status", "new"),
        supabase.from("contact_requests").select("*", { count: "exact", head: true }).eq("status", "new"),
      ]);
      setStats({
        products: p.count ?? 0,
        services: s.count ?? 0,
        customOrdersNew: co.count ?? 0,
        inboxNew: cr.count ?? 0,
      });
    })();
  }, []);

  const cards = [
    { label: "Products", value: stats.products, icon: Package, to: "/admin/products" },
    { label: "Services", value: stats.services, icon: Scissors, to: "/admin/services" },
    { label: "New Custom Orders", value: stats.customOrdersNew, icon: Sparkles, to: "/admin/custom-orders" },
    { label: "Inbox (New)", value: stats.inboxNew, icon: Inbox, to: "/admin/inbox" },
  ] as const;

  return (
    <AdminShell title="Dashboard">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Link key={c.label} to={c.to} className="rounded-2xl bg-card border border-mauve/10 p-5 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</div>
                <div className="font-display text-3xl text-mauve-deep mt-1">{c.value}</div>
              </div>
              <c.icon className="h-6 w-6 text-mauve" />
            </div>
          </Link>
        ))}
      </div>
      <div className="mt-8 rounded-2xl bg-card border border-mauve/10 p-6">
        <h2 className="font-display text-xl text-mauve-deep mb-2">Quick tips</h2>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• Add or edit <strong>Products</strong> — they appear on the Shop instantly.</li>
          <li>• Review <strong>Custom Orders</strong> and resend a pre-filled WhatsApp message to the customer.</li>
          <li>• Filter the <strong>Inbox</strong> by contact requests or service bookings, then export to CSV.</li>
          <li className="flex items-center gap-1.5"><MessageCircle className="h-3.5 w-3.5" /> WhatsApp buttons open a pre-filled chat — no typing needed.</li>
        </ul>
      </div>
    </AdminShell>
  );
}
