import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { Modal, Field, inp } from "./products";

export const Route = createFileRoute("/_authenticated/admin/gallery")({
  component: GalleryAdmin,
});

type Item = { id: string; image: string; caption: string | null; sort_order: number };

function GalleryAdmin() {
  const [rows, setRows] = useState<Item[]>([]);
  const [edit, setEdit] = useState<Partial<Item> | null>(null);

  async function load() {
    const { data } = await supabase.from("gallery").select("*").order("sort_order");
    setRows((data as Item[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function save() {
    if (!edit?.image) { toast.error("Image URL required"); return; }
    const payload = { image: edit.image, caption: edit.caption ?? null, sort_order: Number(edit.sort_order ?? 0) };
    const q = edit.id ? supabase.from("gallery").update(payload).eq("id", edit.id) : supabase.from("gallery").insert(payload);
    const { error } = await q;
    if (error) { toast.error(error.message); return; }
    setEdit(null); load();
  }

  async function remove(id: string) {
    if (!confirm("Delete?")) return;
    await supabase.from("gallery").delete().eq("id", id);
    load();
  }

  return (
    <AdminShell title="Gallery">
      <div className="flex justify-end mb-4">
        <button onClick={() => setEdit({ sort_order: rows.length })} className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
          <Plus className="h-4 w-4" /> Add Image
        </button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {rows.map((r) => (
          <div key={r.id} className="rounded-2xl overflow-hidden bg-card border border-mauve/10">
            <div className="aspect-square bg-blush"><img src={r.image} alt={r.caption ?? ""} className="w-full h-full object-cover" /></div>
            <div className="p-3 flex items-center justify-between text-sm">
              <span className="truncate">{r.caption ?? "—"}</span>
              <div className="flex gap-1">
                <button onClick={() => setEdit(r)} className="p-1.5 hover:bg-blush rounded-lg"><Pencil className="h-3.5 w-3.5" /></button>
                <button onClick={() => remove(r.id)} className="p-1.5 hover:bg-red-50 rounded-lg text-red-600"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          </div>
        ))}
        {rows.length === 0 && <div className="col-span-full text-center text-muted-foreground py-12">No gallery images yet.</div>}
      </div>

      {edit && (
        <Modal onClose={() => setEdit(null)} title={edit.id ? "Edit Image" : "Add Image"}>
          <div className="space-y-3">
            <Field label="Image URL"><input className={inp} value={edit.image ?? ""} onChange={(e) => setEdit({ ...edit, image: e.target.value })} /></Field>
            <Field label="Caption"><input className={inp} value={edit.caption ?? ""} onChange={(e) => setEdit({ ...edit, caption: e.target.value })} /></Field>
            <Field label="Sort order"><input type="number" className={inp} value={edit.sort_order ?? 0} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button onClick={() => setEdit(null)} className="rounded-full px-4 py-2 text-sm border border-mauve/20">Cancel</button>
            <button onClick={save} className="btn-glossy rounded-full px-5 py-2 text-sm font-medium">Save</button>
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}
