import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { MessageCircle, Download, Trash2, Eye, Search } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { waLink, waMessages } from "@/lib/whatsapp";
import { toCSV, downloadCSV } from "@/lib/csv";
import { Modal } from "./products";

export const Route = createFileRoute("/_authenticated/admin/inbox")({
  component: InboxAdmin,
});

type Item = {
  id: string; name: string; mobile: string | null; email: string | null;
  message: string; status: string; kind: string; service_name: string | null; created_at: string;
};

const STATUSES = ["new", "replied", "resolved", "archived"];
const STATUS_STYLES: Record<string, string> = {
  new: "bg-mauve/15 text-mauve-deep",
  replied: "bg-amber-100 text-amber-800",
  resolved: "bg-emerald-100 text-emerald-700",
  archived: "bg-gray-200 text-gray-600",
};

function InboxAdmin() {
  const [rows, setRows] = useState<Item[]>([]);
  const [kind, setKind] = useState<"all" | "contact" | "service_booking">("all");
  const [status, setStatus] = useState<string>("all");
  const [q, setQ] = useState("");
  const [view, setView] = useState<Item | null>(null);

  async function load() {
    const { data, error } = await supabase.from("contact_requests").select("*").order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    setRows((data as Item[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function setItemStatus(id: string, s: string) {
    const { error } = await supabase.from("contact_requests").update({ status: s }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    setRows((r) => r.map((x) => x.id === id ? { ...x, status: s } : x));
    if (view?.id === id) setView({ ...view, status: s });
  }

  async function remove(id: string) {
    if (!confirm("Delete?")) return;
    await supabase.from("contact_requests").delete().eq("id", id);
    load();
  }

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (kind !== "all" && r.kind !== kind) return false;
      if (status !== "all" && r.status !== status) return false;
      if (q) {
        const s = q.toLowerCase();
        if (!(r.name.toLowerCase().includes(s) || (r.email ?? "").toLowerCase().includes(s) || (r.mobile ?? "").includes(s) || r.message.toLowerCase().includes(s))) return false;
      }
      return true;
    });
  }, [rows, kind, status, q]);

  function exportCSV() {
    const csv = toCSV(filtered.map((r) => ({
      created_at: r.created_at, kind: r.kind, status: r.status,
      name: r.name, mobile: r.mobile, email: r.email,
      service_name: r.service_name, message: r.message,
    })));
    downloadCSV(`inbox-${kind}-${new Date().toISOString().slice(0, 10)}.csv`, csv);
  }

  function replyMessage(r: Item) {
    return r.kind === "service_booking"
      ? waMessages.adminServiceFollowUp({ name: r.name, service: r.service_name })
      : waMessages.adminContactFollowUp({ name: r.name, message: r.message });
  }

  return (
    <AdminShell title="Inbox">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex flex-wrap gap-2">
          {(["all", "contact", "service_booking"] as const).map((k) => (
            <button key={k} onClick={() => setKind(k)} className={`text-xs px-3 py-1.5 rounded-full border ${kind === k ? "bg-mauve text-white border-mauve" : "border-mauve/20 hover:bg-blush"}`}>
              {k === "all" ? "All" : k === "contact" ? "Contact" : "Service Bookings"}
            </button>
          ))}
          <span className="mx-1 h-6 w-px bg-mauve/20" />
          {["all", ...STATUSES].map((s) => (
            <button key={s} onClick={() => setStatus(s)} className={`text-xs px-3 py-1.5 rounded-full border ${status === s ? "bg-mauve-deep text-white border-mauve-deep" : "border-mauve/20 hover:bg-blush"}`}>
              {s}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-8 pr-3 py-2 text-sm rounded-full border border-mauve/20 bg-card focus:outline-none focus:ring-2 focus:ring-mauve/30" />
          </div>
          <button onClick={exportCSV} className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm border border-mauve/20 hover:bg-blush">
            <Download className="h-4 w-4" /> CSV
          </button>
        </div>
      </div>

      <div className="rounded-2xl bg-card border border-mauve/10 overflow-x-auto">
        <table className="w-full text-sm min-w-[720px]">
          <thead className="bg-blush/40 text-left">
            <tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">From</th><th className="px-4 py-3">Message</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="border-t border-mauve/10">
                <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(r.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-blush text-mauve-deep">{r.kind === "service_booking" ? "Booking" : "Contact"}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.mobile || r.email || "—"}</div>
                </td>
                <td className="px-4 py-3 max-w-xs">
                  <div className="truncate text-muted-foreground">{r.service_name ? <><b className="text-foreground">{r.service_name}</b> — </> : null}{r.message}</div>
                </td>
                <td className="px-4 py-3">
                  <select value={r.status} onChange={(e) => setItemStatus(r.id, e.target.value)} className={`text-xs px-2 py-1 rounded-full ${STATUS_STYLES[r.status] ?? ""}`}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-1">
                    <button onClick={() => setView(r)} className="p-2 rounded-lg hover:bg-blush" title="View"><Eye className="h-4 w-4" /></button>
                    {r.mobile && (
                      <a href={waLink(replyMessage(r), r.mobile)} target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg hover:bg-green-50 text-green-600" title="Reply via WhatsApp">
                        <MessageCircle className="h-4 w-4" />
                      </a>
                    )}
                    <button onClick={() => remove(r.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">Nothing to show.</td></tr>}
          </tbody>
        </table>
      </div>

      {view && (
        <Modal onClose={() => setView(null)} title={`${view.kind === "service_booking" ? "Booking" : "Message"} — ${view.name}`}>
          <div className="space-y-3 text-sm">
            <Row label="Received" value={new Date(view.created_at).toLocaleString()} />
            <Row label="Mobile" value={view.mobile} />
            <Row label="Email" value={view.email} />
            {view.service_name && <Row label="Service" value={view.service_name} />}
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Message</div>
              <div className="mt-1 whitespace-pre-wrap rounded-xl bg-blush/40 p-3">{view.message}</div>
            </div>
          </div>
          <div className="flex flex-wrap justify-end gap-2 pt-5">
            {view.mobile && (
              <a href={waLink(replyMessage(view), view.mobile)} target="_blank" rel="noopener noreferrer" className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
                <MessageCircle className="h-4 w-4" /> Reply on WhatsApp
              </a>
            )}
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}

function Row({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div className="flex gap-3">
      <div className="w-24 text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div>{value || "—"}</div>
    </div>
  );
}
