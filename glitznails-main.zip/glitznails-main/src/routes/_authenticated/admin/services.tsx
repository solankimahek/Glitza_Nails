import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Pencil, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import type { Service } from "@/lib/products.queries";
import { Modal, Field, inp } from "./products";

export const Route = createFileRoute("/_authenticated/admin/services")({
  component: ServicesAdmin,
});

function ServicesAdmin() {
  const [rows, setRows] = useState<Service[]>([]);
  const [edit, setEdit] = useState<Partial<Service> | null>(null);

  async function load() {
    const { data, error } = await supabase.from("services").select("*").order("sort_order");
    if (error) toast.error(error.message);
    setRows((data as Service[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function save() {
    if (!edit) return;
    const name = edit.name?.trim();
    if (!name) { toast.error("Name required"); return; }
    const payload = {
      name,
      category: edit.category?.trim() || "General",
      description: edit.description ?? null,
      image: edit.image ?? null,
      price_from: edit.price_from == null || (edit.price_from as unknown) === "" ? null : Number(edit.price_from),
      is_active: edit.is_active ?? true,
      sort_order: Number(edit.sort_order ?? 0),
    };
    const q = edit.id
      ? supabase.from("services").update(payload).eq("id", edit.id)
      : supabase.from("services").insert(payload);
    const { error } = await q;
    if (error) { toast.error(error.message); return; }
    toast.success("Saved"); setEdit(null); load();
  }

  async function remove(id: string) {
    if (!confirm("Delete this service?")) return;
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    load();
  }

  return (
    <AdminShell title="Services">
      <div className="flex justify-end mb-4">
        <button onClick={() => setEdit({ is_active: true, sort_order: rows.length, category: "General" })}
          className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
          <Plus className="h-4 w-4" /> New Service
        </button>
      </div>
      <div className="rounded-2xl bg-card border border-mauve/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-blush/40 text-left">
            <tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">From</th><th className="px-4 py-3">Status</th><th /></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-mauve/10">
                <td className="px-4 py-3 font-medium">{r.name}</td>
                <td className="px-4 py-3">{r.category}</td>
                <td className="px-4 py-3">{r.price_from != null ? `₹${r.price_from}` : "—"}</td>
                <td className="px-4 py-3">{r.is_active ? <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">Active</span> : <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Hidden</span>}</td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-2">
                    <button onClick={() => setEdit(r)} className="p-2 rounded-lg hover:bg-blush"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => remove(r.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No services yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {edit && (
        <Modal onClose={() => setEdit(null)} title={edit.id ? "Edit Service" : "New Service"}>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name"><input className={inp} value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Category"><input className={inp} value={edit.category ?? ""} onChange={(e) => setEdit({ ...edit, category: e.target.value })} /></Field>
            <Field label="Price from (₹)"><input type="number" className={inp} value={edit.price_from ?? ""} onChange={(e) => setEdit({ ...edit, price_from: e.target.value === "" ? null : Number(e.target.value) })} /></Field>
            <Field label="Sort order"><input type="number" className={inp} value={edit.sort_order ?? 0} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value) })} /></Field>
            <Field label="Image URL" className="sm:col-span-2"><input className={inp} value={edit.image ?? ""} onChange={(e) => setEdit({ ...edit, image: e.target.value })} /></Field>
            <Field label="Description" className="sm:col-span-2"><textarea rows={3} className={inp} value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!edit.is_active} onChange={(e) => setEdit({ ...edit, is_active: e.target.checked })} /> Active</label>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button onClick={() => setEdit(null)} className="rounded-full px-4 py-2 text-sm border border-mauve/20">Cancel</button>
            <button onClick={save} className="btn-glossy rounded-full px-5 py-2 text-sm font-medium">Save</button>
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}
