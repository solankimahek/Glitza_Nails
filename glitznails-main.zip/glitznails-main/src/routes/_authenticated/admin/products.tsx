import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Pencil, Trash2, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import type { Product } from "@/lib/products.queries";

export const Route = createFileRoute("/_authenticated/admin/products")({
  component: ProductsAdmin,
});

type Draft = Partial<Product> & { imagesText?: string; sizesText?: string };

function ProductsAdmin() {
  const [rows, setRows] = useState<Product[]>([]);
  const [edit, setEdit] = useState<Draft | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase.from("products").select("*").order("sort_order");
    if (error) toast.error(error.message);
    setRows((data as Product[]) ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function save() {
    if (!edit) return;
    const name = edit.name?.trim();
    const slug = edit.slug?.trim();
    if (!name || !slug) { toast.error("Slug and name required"); return; }
    const payload = {
      slug, name,
      description: edit.description ?? null,
      price: Number(edit.price ?? 0),
      category: edit.category ?? null,
      sizes: (edit.sizesText ?? "S,M,L").split(",").map((s) => s.trim()).filter(Boolean),
      images: (edit.imagesText ?? "").split("\n").map((s) => s.trim()).filter(Boolean),
      is_active: edit.is_active ?? true,
      is_featured: edit.is_featured ?? false,
      sort_order: Number(edit.sort_order ?? 0),
    };
    const q = edit.id
      ? supabase.from("products").update(payload).eq("id", edit.id)
      : supabase.from("products").insert(payload);
    const { error } = await q;
    if (error) { toast.error(error.message); return; }
    toast.success("Saved");
    setEdit(null);
    load();
  }

  async function remove(id: string) {
    if (!confirm("Delete this product?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Deleted");
    load();
  }

  return (
    <AdminShell title="Products">
      <div className="flex justify-end mb-4">
        <button onClick={() => setEdit({ sizesText: "S,M,L", imagesText: "", is_active: true, is_featured: false, sort_order: rows.length })}
          className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
          <Plus className="h-4 w-4" /> New Product
        </button>
      </div>
      <div className="rounded-2xl bg-card border border-mauve/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-blush/40 text-left">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">Loading…</td></tr>}
            {!loading && rows.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No products yet.</td></tr>}
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-mauve/10">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {r.images[0] && <img src={r.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover" />}
                    <div>
                      <div className="font-medium">{r.name}</div>
                      <div className="text-xs text-muted-foreground">{r.slug}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">{r.category ?? "—"}</td>
                <td className="px-4 py-3">₹{Number(r.price).toFixed(0)}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    {r.is_active ? <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">Active</span> : <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Hidden</span>}
                    {r.is_featured && <span className="text-xs px-2 py-0.5 rounded-full bg-mauve/15 text-mauve-deep">Featured</span>}
                  </div>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-2">
                    <button onClick={() => setEdit({ ...r, sizesText: r.sizes.join(","), imagesText: r.images.join("\n") })}
                      className="p-2 rounded-lg hover:bg-blush"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => remove(r.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {edit && (
        <Modal onClose={() => setEdit(null)} title={edit.id ? "Edit Product" : "New Product"}>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name"><input className={inp} value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Slug"><input className={inp} value={edit.slug ?? ""} onChange={(e) => setEdit({ ...edit, slug: e.target.value })} /></Field>
            <Field label="Category"><input className={inp} value={edit.category ?? ""} onChange={(e) => setEdit({ ...edit, category: e.target.value })} /></Field>
            <Field label="Price (₹)"><input type="number" className={inp} value={edit.price ?? 0} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} /></Field>
            <Field label="Sizes (comma-separated)"><input className={inp} value={edit.sizesText ?? ""} onChange={(e) => setEdit({ ...edit, sizesText: e.target.value })} /></Field>
            <Field label="Sort order"><input type="number" className={inp} value={edit.sort_order ?? 0} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value) })} /></Field>
            <Field label="Description" className="sm:col-span-2"><textarea rows={3} className={inp} value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
            <Field label="Image URLs (one per line)" className="sm:col-span-2"><textarea rows={3} className={inp} value={edit.imagesText ?? ""} onChange={(e) => setEdit({ ...edit, imagesText: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!edit.is_active} onChange={(e) => setEdit({ ...edit, is_active: e.target.checked })} /> Active</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!edit.is_featured} onChange={(e) => setEdit({ ...edit, is_featured: e.target.checked })} /> Featured</label>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button onClick={() => setEdit(null)} className="rounded-full px-4 py-2 text-sm border border-mauve/20">Cancel</button>
            <button onClick={save} className="btn-glossy rounded-full px-5 py-2 text-sm font-medium">Save</button>
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}

export const inp = "w-full rounded-xl border border-mauve/20 bg-card px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-mauve/30";

export function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <label className={`block ${className}`}><span className="text-xs text-muted-foreground">{label}</span><div className="mt-1">{children}</div></label>;
}

export function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-background rounded-2xl p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-2xl text-mauve-deep">{title}</h2>
          <button onClick={onClose} className="p-2 hover:bg-blush rounded-lg"><X className="h-4 w-4" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
