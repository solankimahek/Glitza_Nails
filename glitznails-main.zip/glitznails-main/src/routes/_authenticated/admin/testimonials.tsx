import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Trash2, Pencil, Star } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { Modal, Field, inp } from "./products";

export const Route = createFileRoute("/_authenticated/admin/testimonials")({
  component: TestimonialsAdmin,
});

type Item = { id: string; name: string; rating: number; review: string; image: string | null; sort_order: number };

function TestimonialsAdmin() {
  const [rows, setRows] = useState<Item[]>([]);
  const [edit, setEdit] = useState<Partial<Item> | null>(null);

  async function load() {
    const { data } = await supabase.from("testimonials").select("*").order("sort_order");
    setRows((data as Item[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function save() {
    if (!edit?.name || !edit?.review) { toast.error("Name and review required"); return; }
    const payload = { name: edit.name, review: edit.review, rating: Number(edit.rating ?? 5), image: edit.image ?? null, sort_order: Number(edit.sort_order ?? 0) };
    const q = edit.id ? supabase.from("testimonials").update(payload).eq("id", edit.id) : supabase.from("testimonials").insert(payload);
    const { error } = await q;
    if (error) { toast.error(error.message); return; }
    setEdit(null); load();
  }

  async function remove(id: string) {
    if (!confirm("Delete?")) return;
    await supabase.from("testimonials").delete().eq("id", id);
    load();
  }

  return (
    <AdminShell title="Testimonials">
      <div className="flex justify-end mb-4">
        <button onClick={() => setEdit({ rating: 5, sort_order: rows.length })} className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
          <Plus className="h-4 w-4" /> Add Review
        </button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {rows.map((r) => (
          <div key={r.id} className="rounded-2xl bg-card border border-mauve/10 p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">{r.name}</div>
                <div className="flex gap-0.5 mt-1">{Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-gold text-gold" />)}</div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => setEdit(r)} className="p-2 hover:bg-blush rounded-lg"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => remove(r.id)} className="p-2 hover:bg-red-50 rounded-lg text-red-600"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-3">{r.review}</p>
          </div>
        ))}
        {rows.length === 0 && <div className="col-span-full text-center text-muted-foreground py-12">No testimonials yet.</div>}
      </div>

      {edit && (
        <Modal onClose={() => setEdit(null)} title={edit.id ? "Edit Review" : "Add Review"}>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Name"><input className={inp} value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Rating (1-5)"><input type="number" min={1} max={5} className={inp} value={edit.rating ?? 5} onChange={(e) => setEdit({ ...edit, rating: Number(e.target.value) })} /></Field>
            <Field label="Image URL" className="sm:col-span-2"><input className={inp} value={edit.image ?? ""} onChange={(e) => setEdit({ ...edit, image: e.target.value })} /></Field>
            <Field label="Review" className="sm:col-span-2"><textarea rows={3} className={inp} value={edit.review ?? ""} onChange={(e) => setEdit({ ...edit, review: e.target.value })} /></Field>
            <Field label="Sort order"><input type="number" className={inp} value={edit.sort_order ?? 0} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button onClick={() => setEdit(null)} className="rounded-full px-4 py-2 text-sm border border-mauve/20">Cancel</button>
            <button onClick={save} className="btn-glossy rounded-full px-5 py-2 text-sm font-medium">Save</button>
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}
