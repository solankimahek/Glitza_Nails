import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { MessageCircle, Download, Trash2, Eye } from "lucide-react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { waLink, waMessages } from "@/lib/whatsapp";
import { toCSV, downloadCSV } from "@/lib/csv";
import { Modal } from "./products";

export const Route = createFileRoute("/_authenticated/admin/custom-orders")({
  component: CustomOrdersAdmin,
});

type Order = {
  id: string; name: string; mobile: string; email: string | null;
  shape: string | null; size: string | null; length: string | null; color: string | null;
  inspiration: string | null; occasion: string | null; notes: string | null;
  status: string; admin_notes: string | null; created_at: string;
};

const STATUSES = ["new", "in_progress", "completed", "cancelled"];
const STATUS_STYLES: Record<string, string> = {
  new: "bg-mauve/15 text-mauve-deep",
  in_progress: "bg-amber-100 text-amber-800",
  completed: "bg-emerald-100 text-emerald-700",
  cancelled: "bg-gray-200 text-gray-600",
};

function CustomOrdersAdmin() {
  const [rows, setRows] = useState<Order[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [view, setView] = useState<Order | null>(null);

  async function load() {
    const { data, error } = await supabase.from("custom_orders").select("*").order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    setRows((data as Order[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function setStatus(id: string, status: string) {
    const { error } = await supabase.from("custom_orders").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    setRows((r) => r.map((o) => o.id === id ? { ...o, status } : o));
    if (view?.id === id) setView({ ...view, status });
  }

  async function remove(id: string) {
    if (!confirm("Delete this order?")) return;
    await supabase.from("custom_orders").delete().eq("id", id);
    load();
  }

  const filtered = useMemo(() => filter === "all" ? rows : rows.filter((r) => r.status === filter), [rows, filter]);

  function exportCSV() {
    const csv = toCSV(filtered.map((r) => ({
      created_at: r.created_at, name: r.name, mobile: r.mobile, email: r.email,
      shape: r.shape, size: r.size, length: r.length, color: r.color,
      inspiration: r.inspiration, occasion: r.occasion, notes: r.notes,
      status: r.status, admin_notes: r.admin_notes,
    })));
    downloadCSV(`custom-orders-${new Date().toISOString().slice(0, 10)}.csv`, csv);
  }

  return (
    <AdminShell title="Custom Orders">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex flex-wrap gap-2">
          {["all", ...STATUSES].map((s) => (
            <button key={s} onClick={() => setFilter(s)} className={`text-xs px-3 py-1.5 rounded-full border ${filter === s ? "bg-mauve text-white border-mauve" : "border-mauve/20 text-foreground hover:bg-blush"}`}>
              {s.replace("_", " ")}
            </button>
          ))}
        </div>
        <button onClick={exportCSV} className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm border border-mauve/20 hover:bg-blush">
          <Download className="h-4 w-4" /> Export CSV
        </button>
      </div>

      <div className="rounded-2xl bg-card border border-mauve/10 overflow-x-auto">
        <table className="w-full text-sm min-w-[720px]">
          <thead className="bg-blush/40 text-left">
            <tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Customer</th><th className="px-4 py-3">Design</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="border-t border-mauve/10">
                <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.mobile}</div>
                </td>
                <td className="px-4 py-3 text-xs">
                  {[r.shape, r.length, r.color].filter(Boolean).join(" · ") || "—"}
                </td>
                <td className="px-4 py-3">
                  <select value={r.status} onChange={(e) => setStatus(r.id, e.target.value)} className={`text-xs px-2 py-1 rounded-full ${STATUS_STYLES[r.status] ?? ""}`}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-1">
                    <button onClick={() => setView(r)} className="p-2 rounded-lg hover:bg-blush" title="View"><Eye className="h-4 w-4" /></button>
                    <a href={waLink(waMessages.adminCustomFollowUp(r), r.mobile)} target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg hover:bg-green-50 text-green-600" title="WhatsApp customer"><MessageCircle className="h-4 w-4" /></a>
                    <button onClick={() => remove(r.id)} className="p-2 rounded-lg hover:bg-red-50 text-red-600"><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No orders in this view.</td></tr>}
          </tbody>
        </table>
      </div>

      {view && (
        <Modal onClose={() => setView(null)} title={`Order — ${view.name}`}>
          <div className="grid gap-3 sm:grid-cols-2 text-sm">
            <Info label="Mobile" value={view.mobile} />
            <Info label="Email" value={view.email} />
            <Info label="Shape" value={view.shape} />
            <Info label="Size" value={view.size} />
            <Info label="Length" value={view.length} />
            <Info label="Color" value={view.color} />
            <Info label="Occasion" value={view.occasion} />
            <Info label="Status" value={view.status} />
            <Info label="Inspiration" value={view.inspiration} className="sm:col-span-2" />
            <Info label="Notes" value={view.notes} className="sm:col-span-2" />
            <Info label="Received" value={new Date(view.created_at).toLocaleString()} className="sm:col-span-2" />
          </div>
          <div className="flex flex-wrap justify-end gap-2 pt-5">
            <a href={waLink(waMessages.adminCustomFollowUp(view), view.mobile)} target="_blank" rel="noopener noreferrer" className="btn-glossy inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium">
              <MessageCircle className="h-4 w-4" /> WhatsApp Customer
            </a>
          </div>
        </Modal>
      )}
    </AdminShell>
  );
}

function Info({ label, value, className = "" }: { label: string; value: string | null | undefined; className?: string }) {
  return (
    <div className={className}>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 whitespace-pre-wrap">{value || "—"}</div>
    </div>
  );
}
