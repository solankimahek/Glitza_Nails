import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Heart, LayoutDashboard } from "lucide-react";
import { Logo } from "./Logo";
import { supabase } from "@/integrations/supabase/client";

const links = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/custom", label: "Custom Nails" },
  { to: "/services", label: "Services" },
  { to: "/gallery", label: "Gallery" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
      setIsAdmin(!!data);
    })();
    const { data: sub } = supabase.auth.onAuthStateChange(async (_e, session) => {
      if (!session?.user) { setIsAdmin(false); return; }
      const { data } = await supabase.rpc("has_role", { _user_id: session.user.id, _role: "admin" });
      setIsAdmin(!!data);
    });
    return () => { window.removeEventListener("scroll", onScroll); sub.subscription.unsubscribe(); };
  }, []);
  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/80 backdrop-blur-xl border-b border-mauve/10 shadow-[0_4px_20px_-12px_oklch(0.55_0.08_10/0.25)]"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-5 lg:px-8 h-16 lg:h-20 flex items-center justify-between">
        <Logo size={42} withText />
        <nav className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              className="text-sm font-medium text-mauve-deep/80 hover:text-mauve transition-colors relative after:content-[''] after:absolute after:-bottom-1.5 after:left-0 after:h-0.5 after:bg-mauve after:w-0 hover:after:w-full after:transition-all"
              activeProps={{ className: "text-mauve after:w-full" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <Link to="/admin" className="hidden sm:inline-flex items-center gap-1.5 h-10 px-3 rounded-full text-sm font-medium bg-mauve/10 hover:bg-mauve/20 text-mauve-deep" aria-label="Admin">
              <LayoutDashboard className="h-4 w-4" /> Admin
            </Link>
          )}
          <Link
            to="/wishlist"
            className="hidden sm:inline-flex w-10 h-10 items-center justify-center rounded-full hover:bg-blush transition-colors text-mauve-deep"
            aria-label="Wishlist"
          >
            <Heart className="h-5 w-5" />
          </Link>
          <button
            type="button"
            className="lg:hidden w-10 h-10 inline-flex items-center justify-center rounded-full hover:bg-blush text-mauve-deep"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden bg-background/95 backdrop-blur-xl border-t border-mauve/10">
          <nav className="mx-auto max-w-7xl px-5 py-4 flex flex-col gap-1">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="px-3 py-3 rounded-lg text-mauve-deep/85 hover:bg-blush"
                activeProps={{ className: "bg-blush text-mauve font-semibold" }}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
