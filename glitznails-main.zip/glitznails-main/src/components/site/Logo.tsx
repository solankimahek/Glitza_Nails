import logo from "@/assets/glitza-logo.png.asset.json";

export function Logo({ size = 44, withText = false }: { size?: number; withText?: boolean }) {
  return (
    <a href="/" className="flex items-center gap-3 group">
      <img
        src={logo.url}
        alt="Glitza Nails by Mahek Solanki"
        width={size}
        height={size}
        className="rounded-full object-cover ring-1 ring-mauve/15 shadow-[0_4px_20px_-8px_oklch(0.55_0.08_10/0.4)] group-hover:scale-105 transition-transform"
        style={{ width: size, height: size }}
      />
      {withText && (
        <span className="font-display text-xl text-mauve-deep tracking-wide">
          Glitza <span className="italic text-mauve">Nails</span>
        </span>
      )}
    </a>
  );
}
