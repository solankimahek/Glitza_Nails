import { Link } from "@tanstack/react-router";
import { Instagram, MapPin, MessageCircle, Phone } from "lucide-react";
import { Logo } from "./Logo";
import { WHATSAPP_NUMBER, waLink, waMessages } from "@/lib/whatsapp";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-mauve/10 bg-gradient-to-b from-background to-blush/40">
      <div className="mx-auto max-w-7xl px-5 lg:px-8 py-14 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-2 space-y-4">
          <Logo size={56} withText />
          <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
            Handmade, reusable, salon-quality press-on nails crafted with love in Anand, Gujarat.
            Custom designs, professional services, and a little bit of sparkle for every story.
          </p>
          <a
            href={waLink(waMessages.general())}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-glossy inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium"
          >
            <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
          </a>
        </div>
        <div>
          <h4 className="font-display text-mauve-deep text-lg mb-4">Explore</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/shop" className="hover:text-mauve">Shop Press-Ons</Link></li>
            <li><Link to="/custom" className="hover:text-mauve">Custom Nails</Link></li>
            <li><Link to="/services" className="hover:text-mauve">Nail Services</Link></li>
            <li><Link to="/size-guide" className="hover:text-mauve">Size Guide</Link></li>
            <li><Link to="/faq" className="hover:text-mauve">FAQ</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-mauve-deep text-lg mb-4">Visit</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 text-mauve" /> Anand, Gujarat, India</li>
            <li className="flex items-start gap-2"><Phone className="h-4 w-4 mt-0.5 text-mauve" /> +91 98987 52225</li>
            <li className="flex items-start gap-2">
              <Instagram className="h-4 w-4 mt-0.5 text-mauve" />
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-mauve">@glitzanails</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-mauve/10 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Glitza Nails by Mahek Solanki · Crafted with love in Anand · WhatsApp +91 {WHATSAPP_NUMBER.slice(2,7)} {WHATSAPP_NUMBER.slice(7)}
      </div>
    </footer>
  );
}
