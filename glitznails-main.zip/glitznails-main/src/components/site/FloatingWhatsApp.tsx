import { useEffect, useState } from "react";
import { ArrowUp, MessageCircle } from "lucide-react";
import { waLink, waMessages } from "@/lib/whatsapp";

export function FloatingWhatsApp() {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <>
      <a
        href={waLink(waMessages.general())}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-5 right-5 z-40 inline-flex items-center justify-center w-14 h-14 rounded-full text-white shadow-[0_10px_30px_-8px_rgba(37,211,102,0.55)] animate-float"
        style={{ background: "linear-gradient(135deg,#25d366,#128c7e)" }}
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      {showTop && (
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          className="fixed bottom-24 right-5 z-40 inline-flex items-center justify-center w-11 h-11 rounded-full bg-card border border-mauve/15 text-mauve-deep shadow-soft hover:bg-blush transition-colors"
        >
          <ArrowUp className="h-5 w-5" />
        </button>
      )}
    </>
  );
}
