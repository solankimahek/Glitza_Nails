
-- Add status/admin_notes to custom_orders
ALTER TABLE public.custom_orders
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS admin_notes TEXT;

CREATE POLICY "Admins update custom orders" ON public.custom_orders
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Add status/kind/service_name to contact_requests
ALTER TABLE public.contact_requests
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'contact',
  ADD COLUMN IF NOT EXISTS service_name TEXT;

GRANT UPDATE ON public.contact_requests TO authenticated;

CREATE POLICY "Admins update contact" ON public.contact_requests
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
